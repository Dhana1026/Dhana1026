#!/bin/bash

 


for ((i=1;i<=10; i++))
do
result=$((i * 7))
        echo "7 X $i =$result"
done
 
