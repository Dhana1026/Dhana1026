#!/bin/bash

 

i=50
while [ $i -ge 2 ]
do
        echo -n "$i "
        i=$(($i-2))
done
ec
