#!/bin/bash

 

i=1
while [ $i -lt 10 ]
do
        echo $i
        i=$(($i+1))
done
